package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class LessonContentFragment : Fragment() {

    companion object {
        private const val ARG_LESSON = "lesson"

        // Fragmentni yaratish uchun factory method
        fun newInstance(lesson: String): LessonContentFragment {
            val fragment = LessonContentFragment()
            val args = Bundle()
            args.putString(ARG_LESSON, lesson)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Fragment layoutini yuklash
        val view = inflater.inflate(R.layout.fragment_lesson_content, container, false)

        // Tanlangan mavzuni olish (hozircha foydalanmaydi, keyin ishlatiladi)
        val lesson = arguments?.getString(ARG_LESSON)

        // Hozircha ikonalar faqat ko'rinadi, keyingi qadamlarda faollashtiriladi
        return view
    }
}
